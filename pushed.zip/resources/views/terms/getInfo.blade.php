

<div>
        
    @include('home.include.user-base')

    <style>
        p{
            margin: 20px 0;
        }
        p,span,a, li{
            font-size: 17px;
        }
        /* ul li{
            list-style-type:square;
            margin-left: 20px;
        } */
    </style>
    <div class="container privacy">
        <div class="text-center">   
             <h2 style="font-size: 25px; font-weight: bold;">Are You Ready become FC ? Registration is open</h2>
            <p>Dear partners and users</p>
        </div>

        <p class="">We congratulate you to decided   to join  the fonepo in the pre-launch period and opening fc account registration on our platform. <span class="">only one who interesting to contribute to constructing  or put stone on this infrastructure the projects    we  called  pioneer members all complete active account automatic join  founder club member Get  super  account  now because  fc </span>has specific limit  number worldwide mix 200 000 <span class="">fc account only</span></p>
    
        <p>Are you in Thousands of people around the worldwide  are yet to join us please the opening of fc account registration on the platform  <span class=""> Only payment through on website <a href="#" style="color:blue;">www.fonepo.com</a>  and after complete pay get activation code immediately and activate after see your fc account activated on Backoffice , you get confirmation email from admin   and no other way for payment beyond site .
 </span></p>

        <ul>
            <li>
                <p>
                     We need you <a href="#" style="color:blue;">enthusiasm</a>  countries fc leaders, Resellers, agent, distributors , staffs    who with the same vision and big thinking, accept challenges, believe in the success of project in the next 5 years because we are  preparing all our services and products they are not work fully we are still developing ecosystem.
                </p>
               

            </li>
            <li>
                <p>
                     WE NEED accompanies join hands to expand us community, build up point of sales that accept this challenges everywhere.
                </p>
               

            </li>
            <li>
                <p>
                    WE NEED local and worldwide   partners to live the dreams, transform fonepo   into one of the most popular platform globally.
                </p>
              
            </li>
        </ul>

        <p >
            Another important thing those activate fc account
Has priority for other feature after launch according step of part launched huge benefits after full launch feature waiting you.

        </p>
        <p>Don't forget that registration is only available via affiliate links to ensure the most fair allocation allowed of new users in the fonepo global.
</p>
        <p style="text-transform: lowercase;">CONNECT WITH US  Work the way you want, earn the way you want and most importantly , live the way you want</p>

        <p > Take well This is your own business, Building together, WE WILL LIVE    DREAMS TOGETHER
</p>
    <p class="font-weight-bold">Regards, Fonepo Team</p>
    </di>



    <script src="{{asset('assets/front/js/jquery-3.3.1.min.js')}}"></script>
        <script src="{{asset('assets/front/js/bootstrap.min.js')}}"></script>
        <script src="{{asset('assets/front/js/owl.carousel.min.js')}}"></script>
        <script src="{{asset('assets/front/js/main.js')}}"></script>
        <script src="{{asset('assets/front/js/jquery-3.3.1.min.js')}}"></script>
        <script src="{{asset('assets/front/js/jquery-migrate-3.0.1.min.js')}}"></script>
        <script src="{{asset('assets/front/js/booststrap.min.js')}}"></script>
        <script src="{{asset('assets/front/js/jquery.stellar.min.js')}}"></script>
        <script src="{{asset('assets/front/js/jquery.waypoints.min.js')}}"></script>
        <script src="{{asset('assets/front/js/jquery.animateNumber.min.js')}}"></script>
        <script src="{{asset('assets/front/js/aos.js')}}"></script>
        <script src="{{asset('assets/front/js/mainj.js')}}"></script>
        <script src="{{asset('assets/front/js/jquerry.min.js')}}"></script>
        <script src="{{asset('assets/front/js/slick.min.js')}}"></script>
        <script src="{{asset('assets/front/js/mainn.js')}}"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous">
        </script>

</div>