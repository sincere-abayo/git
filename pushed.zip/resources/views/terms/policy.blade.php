<title>Privancy Policy</title>
<div>
    
    @include('home.include.user-base')
     <embed src="{{ asset('terms/polic.pdf') }}" type="application/pdf" width="100%" height="600px" />
</div>