<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
      
    </style>
</head>
<body>
    <div>
        <!-- END OF HEADER -->
        @include("home.include.user-base")

           <!-- Breadcrumb Section Begin -->
    <div class="row">
        <div class="sections-navs col-sm-10" style="margin: 0 auto;">
            <h2 style="text-align:center; font-family: Arial, Helvetica, sans-serif; font-weight: bold ; margin: 20px;">Project</h2>
        </div></div>

<style>
     #jjj{
      display:none;
  }
    @media screen and (max-width: 876px) {
  .col-md-6 {
    width: 100%;
    text-align: center;
  }
  #jjj{
      display:block;
      width:100%;
  }
}

</style>

<section class=" ">
    <div class="main_container">
        <div class="">
            <div class="row">
                <div class="col-lg-6">
                    <div class="text-center d-flex align-items-center" style="height: 100%;">
                        <img src="{{asset('assets/front/img/projecs-as1.jpg')}}" alt="fail" style="border-radius: 10px; margin-bottom: 20px; height:400px">
                    </div>
                </div>
                <div class="col-lg-6">
                    <br><br>
                    <div class="ap-title">
                        <p class=""  style="color: #707079;">
                            <span class="stage"> STAGE 1 –</span> – PRELAUNCH. The platform Prelaunch open website allowed fc join in this During the pre-launch process phase
                            for partners to contribute in order to  make masive infrastructure projects . Get  super  fc account this has specific limit  number worldwide mix 
                            200 000 fc account only allowed this projects	and so that you  will get the  MORE BENEFITs  FOR THIS unique opportunity to building a global business,
                            in that a way we  create passive income, never seen possible before anywhere! As a partner/member, you’ll be able to take part of the company’s success in 
                            your hand and a greater part of all future  together.

                        </p>
                        <p class="my-4"  style="color: #707079;">
                            <span class="stage"> STAGE 2 –</span>has three phrase; Fonepo will LAUNCH ,fomo which way generate money through (watch video, complete tasks, 
                            click views ,download app, survey and online gaming play ) and open for all users/ partners process phase1 . process phase2. Fonepo  full operational 
                            model The revolutionary recurring bonus systems are activated and all members can now inviting/referral friends from all over the world  process: phase2
                         Fonepo	open  full operated and activated Future AI BOT, E business, Future booking.

                        </p>
                        <p class="my-4"  style="color: #707079;">
                           <span class="stage"> STAGE 3 –</span> – Fonepo  will LAUNCH, and starting to activate  flexible staking options,  Future Chat , distributors coins
                           And allowed distributors/ agent .

                          </p>
                          <p class="my-4"  style="color: #707079;">
                          <span class="stage"> STAGE 4 –</span> Fonepo will LAUNCH, crypto loan, money transfer, exchange and full all feature option.


                          </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>




<section class=" " >
    <div class="main_container">
        <div class="about-page-text my-4">
            <div class="row">
                <div class="col-lg-6">
                    <div class="ap-title">
                        <p>
                          FOM license/Reserved credit coins for  DURING PRELAUNCH The earlier you join and activated  fc account in period pre prelaunch, the more beneficial for program  you will get second dashboard, already  upgrade VIP2, Get reward for 100 000ads /projects/ bring by client / complete uploaded worldwide  each  get 0.009%, more feature activated, as the coin will steadily increase in value soon as possible . The FOM will only be available during the prelaunch and with the growth during prelaunch and directly after launch the  value more growth

                        </p>
                        <p class="paragraph">
                            THIS IS EXCLUSIVE ACCESS TO FONEPO - FONEPO reserves 50 people for the first 100 members
                            in a country activated account become FCM and first-come-first-serve basis for FCM (founder
                            Club Members) this benefit is very huge.
                        </p>
                    </div>
                </div>
                <div class="col-lg-5 offset-lg-1 set-bg" data-setbg="{{asset('assets/front/img/proj.png')}}" style="border-radius: 10px;">
                   
                </div>
                   <div id="jjj" class="col-lg-5 offset-lg-1 set-bg" >
                    <img src="{{asset('assets/front/img/proj.png')}}" width="100%" style="border-radius: 10px;" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<center>
<section class="my-5">
    <div class="main_container">
        <div>
          
                    <div class="ap-title">
                        <h3>Amazing Fonepo & innovative products</h3>
                        <p style="color: #707079;">
                            FONEPO offers a wide range of products and services. Some are already available; others are
                            currently being developed. We are constantly looking at our offering and adding products that
                            we know will best serve our affiliates on their quest for a happier life in globally .
                        </p>
               
        </div>
    </div>
</section></center>
    <!-- STARTING OF FOOTER -->
    @include("home.include.footer")
</body>
</html>
