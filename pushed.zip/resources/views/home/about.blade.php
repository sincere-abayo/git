<div>
        @include('home.include.user-base')

<div class="my-4">
        <div class="main_container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-text">
                        <h3 style="font-family: Arial, Helvetica, sans-serif;">About Us</h3>
                        <p class="about-par">Fonepo is bridges connects	the gap between traditional marketing , innovate technology and the digital marketing in
                        world and solutions aims to transform global enterprises digitally	where	we offers innovative business	which enable companies from
                        around the world to sell their products/service	to customers for latest technology , interacting with a global audience through revolutionary
                        solutions affiliate platform.
.</p>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Section End -->
 <div class="breadcrumb-text"> <h3 style="font-family: Arial, Helvetica, sans-serif;">WHAT IS FONEPO</h3> </div>
    <!-- About Us Page Section Begin -->
    <section class="main_container">
    
         
                <div class="row">
                    <div class="col-lg-6">
                        <div class="breadcrumb-text pt-5" style="">
                            
                            <p class="about-par">
                                Fonepo  is a unique innovative next generation referral program platform solutions, connecting three great communities t
                                hat can benefit each other where build the future massive infrastructure project which combining the innovation technology AI,
                                web3, blockchain. There are companies who have world-class and innovative products/services, a huge community of sellers who can 
                                promote their products, as well as hundreds of millions of happy customers wanting to gain access of feature to these amazing platforms
                                where we help millions of people transform their lives.

                            </p><br>
                            
                          <p class="about-par">
                                <!--<h2 style="font-size: 20px; font-weight: bold;">-->
                                We are combining traditional marketing, AI marketing, social media marketing, 
                                and affiliate marketing opportunities to promote your product and service. This helps 
                                provide high levels of residual income for all our affiliate members. We help you spread
                                potential information to everyone, anywhere in the world.
                                </p>
                        </div>                
                    </div>
                    <div class="col-lg-6 d-flex justify-content-center">
                        <img src="assets/front/img/sm-banner1.jpg" alt="fail" style="border-radius:10px;">
                    </div>
                                 
                </div>
                    <div >
                        <div class="ap-title my-5">
                            <h3 style="color: #707079; font-size: 18px; text-align: center">Fonepo  have created a unique solutions system for global community of people who love innovative technologies, blockchain technologies
                             and opened access for all people to benefit from a system we can implement
                              future innovations today  which just<br> a few years ago was only accessible
                              for big companies.</h3>
                            
                        </div>
                </div>
            
        </div>
    </section>

@include('home.include.footer')
 </div>