<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/64af5f0194cf5d49dc633c00/1h56gm8bh';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
    <footer class="footer-section">
            <div class="main_container">
                <div class="footer-text">
                    <div class="fot-flex-row">
                    <div class="fot-flex">
                            <div class="ft-about">
                            
                                <p>our solution is to help people to achieving their goals
                                    and to give everyone financial freedom for innovation technology friendly users to spend time, full access
                                    on platform</p>
</p>
                                <div class="fa-social">
                
                                    <a href="https://www.facebook.com/profile.php?id=100095140128076" target="__blank"><span style="font-size: 24px;">
                                        <i class="fa fa-facebook"></i>
                                    </span></a>        
                                    <a href="https://twitter.com/fonepo1" target="__blank"> <span style="font-size: 24px;"> <i class="fa fa-twitter"></i></span></a>

                                    <a href="https://discord.com/channels/1132778267586343036/1132778269054345298" target="__blank"><svg xmlns="http://www.w3.org/2000/svg" width="3rem"  viewBox="0 0 644 512" ><path d="M524.531,69.836a1.5,1.5,0,0,0-.764-.7A485.065,485.065,0,0,0,404.081,32.03a1.816,1.816,0,0,0-1.923.91,337.461,337.461,0,0,0-14.9,30.6,447.848,447.848,0,0,0-134.426,0,309.541,309.541,0,0,0-15.135-30.6,1.89,1.89,0,0,0-1.924-.91A483.689,483.689,0,0,0,116.085,69.137a1.712,1.712,0,0,0-.788.676C39.068,183.651,18.186,294.69,28.43,404.354a2.016,2.016,0,0,0,.765,1.375A487.666,487.666,0,0,0,176.02,479.918a1.9,1.9,0,0,0,2.063-.676A348.2,348.2,0,0,0,208.12,430.4a1.86,1.86,0,0,0-1.019-2.588,321.173,321.173,0,0,1-45.868-21.853,1.885,1.885,0,0,1-.185-3.126c3.082-2.309,6.166-4.711,9.109-7.137a1.819,1.819,0,0,1,1.9-.256c96.229,43.917,200.41,43.917,295.5,0a1.812,1.812,0,0,1,1.924.233c2.944,2.426,6.027,4.851,9.132,7.16a1.884,1.884,0,0,1-.162,3.126,301.407,301.407,0,0,1-45.89,21.83,1.875,1.875,0,0,0-1,2.611,391.055,391.055,0,0,0,30.014,48.815,1.864,1.864,0,0,0,2.063.7A486.048,486.048,0,0,0,610.7,405.729a1.882,1.882,0,0,0,.765-1.352C623.729,277.594,590.933,167.465,524.531,69.836ZM222.491,337.58c-28.972,0-52.844-26.587-52.844-59.239S193.056,219.1,222.491,219.1c29.665,0,53.306,26.82,52.843,59.239C275.334,310.993,251.924,337.58,222.491,337.58Zm195.38,0c-28.971,0-52.843-26.587-52.843-59.239S388.437,219.1,417.871,219.1c29.667,0,53.307,26.82,52.844,59.239C470.715,310.993,447.538,337.58,417.871,337.58Z" style="fill: white;"/></svg></a>
            
                            </div>
                            </div>
                            
                        </div>
                        <div class="fot-flex2">
                            <div class="ft-contact">
                                <h6 class="text-center">Contact Us</h6>
                                
                                <div class="footer-contact ">


                                    <div class="fot-contact-col">
                                    
                                        <div class="trow">
                                                
                                                <div class="">
                                                    <div class="simbol">
                                                        <img src="{{asset('assets/front/img/admin.png')}}" alt="">
                                                    </div>
                                                </div>
                                                <div class="fot-addr-name">ADMIN::   </div>
                                                <div class="fot-addr-link">
                                                    <div class="d-flex flex-column">
                                                         <div><a href="mailto:info@fonepo.com">info@fonepo.com</a></div>
                                                        <div><a href="mailto:suport@fonepo.com">suport@fonepo.com</a></div>
                                                    </div>  
                                                </div>
                                            </div>
                                            <div class="trow">
                                                
                                                <div class="">
                                                    <div class="simbol">
                                                        <img src="{{asset('assets/front/img/white-house.png')}}" alt="">
                                                    </div>
                                                </div>
                                                <div class="fot-addr-name">USA TEAM: </div>
                                                <div class="fot-addr-link">
                                                    <div class=" d-flex flex-column">
                                                        <div><a href="mailto:usasuport@fonepo.com">usasuport@fonepo.com   </a></div>
                                                        <div><a href="mailto:servicefonepo@gmail.com">servicefonepo@gmail.com </a></div>
                                                    </div>      
                                                
                                                </div>
                                            </div>
                                             <div class="trow">
                                                
                                                <div class="">
                                                    <div class="simbol">
                                                        <img src="{{asset('assets/front/img/houses.png')}}" alt="">
                                                    </div>
                                                </div>
                                                <div class="fot-addr-name">SUEDE TEAM:   </div>
                                                <div class="fot-addr-link">
                                                    <div class=" d-flex flex-column">
                                                        <div><a href="mailto:suedesuport@fonepo.com">suedesuport@fonepo.com </a></div>
                                                        <div><a href="mailto:servicefonepo@gmail.com">servicefonepo@gmail.com </a></div>
                                                    </div>      
                                                
                                                </div>
                                            </div>
                                    </div>


                                    <div class="fot-contact-col">
                                             <div class="trow">
                                                
                                                <div class="">
                                                    <div class="simbol">
                                                        <img src="{{asset('assets/front/img/south-africa.png')}}" alt="">
                                                    </div>
                                                </div>
                                                <div class="fot-addr-name">SOUTHAFRICA TEAM:   </div>
                                                <div class="fot-addr-link">
                                                    <div class="d-flex flex-column">
                                                         <div><a href="mailto:sfsuport@fonepo.com">sfsuport@fonepo.com  </a></div>
                                                        <div><a href="mailto:fonepoteam@gmail.com">fonepoteam@gmail.com </a></div>
                                                    </div>  
                                                </div>
                                            </div>
                                            <div class="trow">
                                                
                                                <div class="">
                                                    <div class="simbol">
                                                        <img src="{{asset('assets/front/img/woman.png')}}" alt="">
                                                    </div>
                                                </div>
                                                <div class="fot-addr-name">KENYA TEAM:  </div>
                                                <div class="fot-addr-link">
                                                    <div class=" d-flex flex-column">
                                                        <div><a href="mailto:kesuport@fonepo.com">kesuport@fonepo.com </a></div>
                                                        <div><a href="mailto:servicefonepo@gmail.com">servicefonepo@gmail.com</a></div>
                                                    </div>      
                                                
                                                </div>
                                            </div>
                                             <div class="trow">
                                                
                                                <div class="" >
                                                    <div class="simbol">
                                                        <img src="{{asset('assets/front/img/kigali.png')}}" alt="">
                                                    </div>
                                                </div>
                                                <div class="fot-addr-name">ROMANIA TEAM:  </div>
                                                <div class="fot-addr-link">
                                                    <div class=" d-flex flex-column">
                                                         <div><a href="mailto:rwasuport@fonepo.com">rwasuport@gmail.com </a></div>
                                                        <div><a href="mailto:fonepoteam@gmail.com.com">fonepoteam@gmail.com</a></div>
                                                    </div>      
                                                
                                                </div>
                                            </div>
                                    </div>


                                </div>
                            
                            </div>
                        
                        </div>
                        <div class="fot-flex3">
                            <div class="ft-newslatter">
                                <h6>New latest</h6>
                                <p>Get the latest updates and offers.</p>
                                <form action="{{route('latest')}}" method="get" class="fn-form">
                                    <input type="text" placeholder="Email" name="email">
                                    <button type="submit"><i class="fa fa-send"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copyright-option">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8">
                            <ul>
                                <!--<li><a href="#">FAQ</a></li>-->
                                <li><a href="{{ route('tam')}}" target="__blank">Terms of use</a></li>
                                <li><a href="{{ route('policy')}}" target="__blank">Privacy</a></li>
                                <li><a href="#">Copyright &copy;<script>document.write(new Date().getFullYear());</script>    &nbsp;&nbsp;&nbsp;<i class="fa fa-heart" aria-hidden="true"></i>All rights reserved</a></li>
                                <li>
                            <!--<div class="co-text"> -->
                            
                            <!--</div>-->
                            </li>
                            </ul>
                        </div>
                    
                    </div>
                </div>
            </div>
        </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="{{asset('assets/front/js/jquery-3.3.1.min.js')}}"></script>
    <script src="{{asset('assets/front/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('assets/front/js/owl.carousel.min.js')}}"></script>
    <script src="{{asset('assets/front/js/main.js')}}"></script>
    <script src="{{asset('assets/front/js/jquery-3.3.1.min.js')}}"></script>
    <script src="{{asset('assets/front/js/jquery-migrate-3.0.1.min.js')}}"></script>
    <script src="{{asset('assets/front/js/booststrap.min.js')}}"></script>
    <script src="{{asset('assets/front/js/jquery.stellar.min.js')}}"></script>
    <script src="{{asset('assets/front/js/jquery.waypoints.min.js')}}"></script>
    <script src="{{asset('assets/front/js/jquery.animateNumber.min.js')}}"></script>
    <script src="{{asset('assets/front/js/aos.js')}}"></script>
    <script src="{{asset('assets/front/js/mainj.js')}}"></script>
    <script src="{{asset('assets/front/js/jquerry.min.js')}}"></script>
    <script src="{{asset('assets/front/js/slick.min.js')}}"></script>
    <script src="{{asset('assets/front/js/mainn.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous">
    </script>
 