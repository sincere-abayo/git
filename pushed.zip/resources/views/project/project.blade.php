 <div>
     @include('user.user-dashboard-base')


        <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <br><br>

    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
       <!--  <ul class="nav nav-tabs">
            <li class="active"><a  href="{{route('user.dashboard')}}">Package List</a></li>
            <li ><a  href="{{route('user.dashboard')}}">Purchased Packages</a></li>
          
          </ul> --><center>
          <h3> Upload project : Advertise on Fonepo</h3></center>
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container">
      <div class="row">
        <div class="col-md-4">
          
            <div class="card-body ">
              <div class="info bg-secondary">
  
                  <center>
                    <div class="text-center "><h4 class="font-size-20 font-weight-600">Paid to Click (PTC)</h4> <span class="font-size-12 ">Drive traffic to your website, get views on your service.</span></div>
                    <hr>
                   
                 
                <!-- /.info-box-content -->
              <div>
                                 <img style="margin-top: -25px;" src="{{asset('assets/a/img/click.png')}}">

              </div>
<style type="text/css">
     .a{
        padding-top: 10px;
        color: red;
    }
</style>
                <div class="bg-info container-fluid">
                  <div class="col-md-12">
                    <center>
                        <div class="btn btn-warning">
<a href="{{route('user.dashboard.ptc')}}"> MANAGE A PTC AD</a>
        </div>
</center>
                    <br>
                  </div>
                </div>
              </div>
            </div>
         
         
        </div>
         <!-- END OF cl -->
         <div class="col-md-4">
          
          <div class="card-body">
            <div class="info bg-secondary">

                <center> <div class="text-center"><h4 class="font-size-20 font-weight-600">Paid to Watch (PTW)</h4> <span class="font-size-12 ">Drive traffic to your website, get views on your video.</span></div>
                    <hr></center>
              
              <!-- /.info-box-content -->
             <div>
                 <img style="margin-top: -10px;" src="{{asset('assets/a/img/video.png')}}">
                 <!-- <span>Video watches</span> -->
             </div>

              <div class="bg-info container-fluid">
                <div class="col-md-12">
                  <center><div class="btn btn-warning">
<a href="{{route('user.dashboard.video')}}">
                    MANAGE VIDEO AD
    
</a>                  </div></center>
                  <br>
                </div>
              </div>
            </div>
          </div>
       
       
      </div>
       <!-- END OF cl -->
       <div class="col-md-4">
          
        <div class="card-body">
          <div class="info bg-secondary">

              <center>
 <div class="text-center"><h4 class="font-size-20 font-weight-600">Paid to Downloads (PTD)</h4> <span class="font-size-12 ">Drive traffic to your website, get views on your App.</span></div>
                    <hr>
              </center>
                <!-- /.info-box-content -->
        <div> <center><img style="margin-top: -30px;"src="{{asset('assets/a/img/download.png')}}" width="200px" height="200px"></center>
</div>
            <div class="bg-info container-fluid" style="margin-top:-30px">
              <div class="col-md-12">
                <center><div class="info">
              <a href="" class="btn btn-warning" style="color: white">   MANAGE A DOWNLOADABLE APP &nbsp;&nbsp;&nbsp;<span style="color: red;">coming soon</span></a>
                </div></center>
                <br>
              </div>
            </div>
          </div>
        </div>
     
     
    </div>
     <!-- END OF cl -->
        </div>
    
         <!-- END OF cl -->
      
       
       
      </div>
       <!-- END OF cl -->
     
    </div>
     <!-- END OF cl -->
        </div>
         
       
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
    <!-- /.row -->

  </div>
 </div>