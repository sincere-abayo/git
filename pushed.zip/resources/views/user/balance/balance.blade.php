<div class="wrapper">
@include('user.user-dashboard-base')


 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        
 <!-- Content Wrapper. Contains page content -->

 <div class="content-wrapper" id="center-side">

        <div class="content">
            <div class="container-fluid">
                                <div class="bal-box-container">
                    <div class="bal-box">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                           Cash out
                        </div>
                        <div class="bal-num text-danger font-weight-bold text-lg">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            Trading
                        </div>
                        <div class="bal-num text-danger font-weight-bold text-lg">
                            0.0
                        </div>
                    </div> 
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            mcoin
                        </div>
                        <div class="bal-num text-danger font-weight-bold text-lg">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            cash & deposite
                        </div>
                        <div class="bal-num text-danger font-weight-bold text-lg">
                            0.0
                        </div>
                    </div> 

                     <div class="bal-box">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            Escrow mshare
                        </div>
                        <div class="bal-num text-danger font-weight-bold text-lg">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            holding
                        </div>
                        <div class="bal-num text-danger font-weight-bold text-lg">
                            0.0
                        </div>
                    </div> 
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            escrow mshare
                        </div>
                        <div class="bal-num text-danger font-weight-bold text-lg">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div> 

                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>

                     <div class="bal-box box-blue">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            Coming soon
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div> 

                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>  

                     <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>

                                        <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box bg-danger">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-white">
                            Total earning
                        </div>
                        <div class="bal-num">
                            $0.0
                        </div>
                    </div>  

                     <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div> 

                                        <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>    
                    <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>  

                     <div class="bal-box ">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            <p>Total earning</p>
                        </div>
                        <div class="bal-num">
                            0.0
                        </div>
                    </div>    
                       <div class="bal-box box-blue">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            Coming soon
                        </div>
                    </div> 

                     <div class="bal-box box-lightBlue">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            Total earning
                        </div>
                        <div class="bal-num font-weight-bold text-lg">
                            0.0
                        </div>
                    </div> 
   
                     <div class="bal-box box-blue">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content">
                            Coming soon
                        </div>
                    </div> 

                     <div class="bal-box box-lightBlue">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            Total earning
                        </div>
                        <div class="bal-num font-weight-bold text-lg">
                            0.0
                        </div>
                    </div> 
  
                    <div class="bal-box box-lightBlue">
                        <div class="point">
                            
                        </div>
                        <div class="bal-content text-danger font-weight-bold text-lg">
                            Total earning
                        </div>
                        <div class="bal-num font-weight-bold text-lg">
                            0.0
                        </div>
                    </div> 




                </div>
                
        </div>
 </div>

</div>

<script>
document.addEventListener('livewire:load', function() {

// $('#exampleModal').modal('show');

})
</script>


