  <!-- Main Footer -->
  <footer class="main-footer">
      <!-- To the right 
      <div class="float-left d-none d-sm-block">

      </div>
      <strong>Copyright &copy;{{date('Y')}} <a href="https://muhahe.com"> fonepo
              Ltd</a>.</strong>
      All
      rights
      reserved.
      -->
  </footer>
  <!-- jQuery -->

  <script src="{{asset('assets/a/plugins/jquery/jquery.min.js')}}"></script>
  <!-- Bootstrap 4 -->
  <script src="{{asset('assets/a/plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('assets/a/plugins/sparklines/sparkline.js')}}"></script>
  <!-- AdminLTE App -->
  <script src="{{asset('assets/a/plugins/jquery-ui/jquery-ui.min.js')}}"></script>
  <script src="{{asset('assets/a/dist/js/adminlte.min.js')}}"></script>
  <script src="{{asset('assets/a/dist/js/adminlte.js')}}"></script>
  <script src="{{asset('assets/a/plugins/chart.js/Chart.min.js')}}"></script>
  <script src="{{asset('assets/a/dist/js/pages/dashboard2.js')}}"></script>
  <script src="{{asset('assets/a/dist/js/tree.js')}}"></script>
  <script src="{{asset('assets/a/plugins/chart.js/Chart.min.js')}}"></script>
  <script src="{{asset('assets/a/plugins/jquery-knob/jquery.knob.min.js')}}"></script>

  <script src="{{asset('assets/a/dist/js/pages/dashboard.js')}}"></script>
  <script src="{{asset('assets/a/plugins/summernote/summernote-bs4.min.js')}}"></script>
  <script src="{{asset('assets/a/plugins/daterangepicker/daterangepicker.js')}}"></script>
  <script src="{{asset('assets/a/plugins/moment/moment.min.js')}}"></script>
  <script src="{{asset('assets/a/dist/js/pages/dashboard3.js')}}"></script>
    <script  src="{{asset('assets/a/js/custom.js')}}" ></script>