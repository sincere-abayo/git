<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class Requested extends Controller
{
    public function requested()
    {
        return view('admin.user-request');
      
    }
     public function subscribe()
    {
        return view('admin.user-subscribe');
      
    }
}
