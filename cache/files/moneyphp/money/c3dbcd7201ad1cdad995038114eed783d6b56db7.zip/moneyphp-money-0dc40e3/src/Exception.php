<?php

namespace Money;

/**
 * Common interface for all exceptions thrown by this library.
 *
 * @author Frederik Bosch <f.bosch@genkgo.nl>
 */
interface Exception
{
}
